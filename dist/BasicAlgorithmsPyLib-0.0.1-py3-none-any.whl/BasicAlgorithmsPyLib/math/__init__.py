from .factorial import factorial_iterative, factorial_recursion
from .fibonacci import fibonacci_iterative, fibonacci_recursion